<style>
  div {
    background: #19191c;
    max-width: 800px;
    margin: 32px auto;
    padding: 32px;
  }
  @media screen and (max-width: 900px) {
    div {
      margin: 0 auto;
    }
  }
</style>

<div>
  <slot />
</div>
