Requires a .env file with:

EMAIL_ADDRESS=<the address for emails to be sent to>
EMAIL_USERNAME=<the username for the Gmail SMTP server>
EMAIL_PASSWORD=<the App Password for the Gmail SMTP server>
