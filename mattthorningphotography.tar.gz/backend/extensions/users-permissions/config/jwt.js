module.exports = {
  jwtSecret: process.env.JWT_SECRET || '5f56504f-e9d9-4ac0-a981-77b0571cc8d7'
};