<script>
  import Error from './_error.svelte'
</script>

<Error>
  There has been an error contacting PayPal, please try again or contact me on
  <a href="mailto:matthewthorning@gmail.com">matthewthorning@gmail.com</a>
  for assistance
</Error>
