<style>
  div {
    margin: 0 auto;
    padding: 32px;
  }
</style>

<div>
  <slot />
</div>
