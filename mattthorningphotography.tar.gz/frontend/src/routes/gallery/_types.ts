import type { Photo } from '../../types'

export interface Data {
    photos: Array<Photo>
}
