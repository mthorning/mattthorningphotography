<script>
  import PageLayout from '../_pageLayout.svelte'
</script>

<PageLayout>
  <slot />
</PageLayout>
