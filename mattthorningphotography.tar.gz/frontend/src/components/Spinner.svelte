<script lang="ts">
  export let style = ''
</script>

<style>
  div {
    background-image: url('/spinner.gif');
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center;
    height: 100%;
    width: 100%;
  }
</style>

<div {style} />
